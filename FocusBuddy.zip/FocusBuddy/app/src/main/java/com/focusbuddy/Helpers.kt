package com.focusbuddy

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import kotlin.math.roundToInt

object Suggestions {
    private val morning = listOf(
        "Revise yesterday's chapter from memory, then check what you missed.",
        "Solve 10 previous-year questions from your weakest subject.",
        "Do one full chapter of your hardest subject with a 25-minute timer."
    )
    private val afternoon = listOf(
        "Practice numericals or problems for 30 minutes, no phone nearby.",
        "Write all key formulas of one chapter on a single page.",
        "Attempt a timed mock section and mark your mistakes."
    )
    private val evening = listOf(
        "Make flashcards for today's topics and test yourself once.",
        "Revise one chapter using active recall: close the book, write what you remember.",
        "Fix the mistakes from your last test, one by one."
    )
    private val night = listOf(
        "Light revision: read your short notes for 20 minutes, then sleep early.",
        "Plan tomorrow's three study tasks on paper, then rest."
    )

    fun task(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val list = when {
            h in 5..11 -> morning
            h in 12..16 -> afternoon
            h in 17..21 -> evening
            else -> night
        }
        return list.random()
    }

    fun songQuery(mood: String, weather: String): String {
        val moodWord = when (mood) {
            "Sad" -> "soothing"
            "Stressed" -> "calm relaxing"
            "Sleepy" -> "upbeat energetic"
            "Focused" -> "peaceful instrumental"
            else -> "feel good"
        }
        val weatherWord = when (weather) {
            "rainy", "stormy" -> "rain"
            "sunny" -> "morning"
            "cloudy", "foggy" -> "evening"
            else -> ""
        }
        return "kannada melody songs $moodWord $weatherWord".trim()
    }
}

object Cities {
    // City name -> (latitude, longitude). Add your own city here.
    val list: Map<String, Pair<Double, Double>> = linkedMapOf(
        "Bengaluru" to Pair(12.97, 77.59),
        "Mysuru" to Pair(12.30, 76.64),
        "Mangaluru" to Pair(12.91, 74.86),
        "Hubballi" to Pair(15.36, 75.12),
        "Belagavi" to Pair(15.85, 74.50),
        "Kalaburagi" to Pair(17.33, 76.83),
        "Shivamogga" to Pair(13.93, 75.57),
        "Davanagere" to Pair(14.47, 75.92)
    )
}

data class WeatherInfo(val label: String, val tempC: Int)

object Weather {
    /** Live weather from Open-Meteo (free, no key). Call off the main thread. Null if offline. */
    fun fetch(lat: Double, lon: Double): WeatherInfo? {
        return try {
            val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current_weather=true")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 6000
            conn.readTimeout = 6000
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val cw = JSONObject(text).getJSONObject("current_weather")
            WeatherInfo(describe(cw.getInt("weathercode")), cw.getDouble("temperature").roundToInt())
        } catch (e: Exception) {
            null
        }
    }

    private fun describe(code: Int): String = when (code) {
        0, 1 -> "sunny"
        2, 3 -> "cloudy"
        45, 48 -> "foggy"
        in 51..67, in 80..82 -> "rainy"
        in 95..99 -> "stormy"
        else -> "cloudy"
    }

    fun tip(label: String): String = when (label) {
        "rainy", "stormy" -> "Rain outside. A good time for a long study block."
        "sunny" -> "Bright day. Study near a window and take a 5-minute walk break."
        "foggy" -> "Foggy and quiet. Good for slow, careful revision."
        else -> "Cloudy and calm. Good for focused practice."
    }

    fun pretty(label: String) = label.replaceFirstChar { it.uppercase() }
}
