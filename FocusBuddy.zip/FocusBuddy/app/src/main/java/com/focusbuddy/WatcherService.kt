package com.focusbuddy

import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.app.Notification
import android.widget.Toast
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class WatcherService : AccessibilityService() {

    companion object {
        const val CHANNEL = "focus_nudges"
        const val PREFS = "fb"
        const val NUDGE_AFTER_MS = 3 * 60 * 1000L      // nudge after 3 min of wasting time
        const val HOME_AFTER_MS = 5 * 60 * 1000L       // push you to Home after 5 min
        const val TICK_MS = 15_000L

        fun todayKey(): String =
            "ms_" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
    }

    // Always counted as time wasting
    private val alwaysDistracting = setOf(
        "com.snapchat.android",
        "in.mohalla.sharechat",
        "com.zhiliaops.zili",
        "com.facebook.katana"
    )
    // Only counted when the Shorts / Reels screen is showing
    private val shortFormApps = setOf(
        "com.google.android.youtube",
        "com.instagram.android"
    )

    private val handler = Handler(Looper.getMainLooper())
    private var currentPkg = ""
    private var lastCheck = 0L
    private var wastedMs = 0L
    private var nudged = false

    private val tick = object : Runnable {
        override fun run() {
            check()
            handler.postDelayed(this, TICK_MS)
        }
    }

    override fun onServiceConnected() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Focus nudges", NotificationManager.IMPORTANCE_HIGH)
        )
        lastCheck = SystemClock.elapsedRealtime()
        handler.postDelayed(tick, TICK_MS)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        // ignore ourselves, the status bar and the keyboard
        if (pkg == packageName || pkg == "com.android.systemui" || pkg.contains("inputmethod")) return
        currentPkg = pkg
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    private fun check() {
        val now = SystemClock.elapsedRealtime()
        val dt = now - lastCheck
        lastCheck = now

        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isInteractive) {
            wastedMs = 0; nudged = false
            return
        }

        val bad = isDistracting(currentPkg)
        saveLast(bad)
        if (bad) {
            wastedMs += dt
            val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
            val key = todayKey()
            prefs.edit().putLong(key, prefs.getLong(key, 0L) + dt).apply()

            if (wastedMs >= HOME_AFTER_MS) {
                performGlobalAction(GLOBAL_ACTION_HOME)
                wastedMs = 0; nudged = false
            } else if (wastedMs >= NUDGE_AFTER_MS && !nudged) {
                nudge()
                nudged = true
            }
        } else {
            wastedMs = 0; nudged = false
        }
    }

    /** Remembers the last screen seen so the main screen can show what the watcher sees. */
    private fun saveLast(bad: Boolean) {
        if (currentPkg.isEmpty()) return
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(currentPkg, 0)).toString()
        } catch (e: Exception) {
            currentPkg
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString("last_app", label)
            .putString("last_state", if (bad) "wasting time" else "ok")
            .apply()
    }

    private fun isDistracting(pkg: String): Boolean {
        if (pkg.isEmpty()) return false
        if (pkg in alwaysDistracting) return true
        if (pkg in shortFormApps) return hasShortFormScreen(rootInActiveWindow)
        return isGame(pkg)
    }

    private fun isGame(pkg: String): Boolean = try {
        packageManager.getApplicationInfo(pkg, 0).category == ApplicationInfo.CATEGORY_GAME
    } catch (e: Exception) {
        false
    }

    /** Looks for Reels / Shorts markers in view ids, text and descriptions (bounded search). */
    private fun hasShortFormScreen(root: AccessibilityNodeInfo?): Boolean {
        if (root == null) return false
        var visited = 0
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        while (stack.isNotEmpty() && visited < 400) {
            val n = stack.removeAt(stack.size - 1)
            visited++
            val id = n.viewIdResourceName?.lowercase() ?: ""
            val text = n.text?.toString()?.lowercase() ?: ""
            val desc = n.contentDescription?.toString()?.lowercase() ?: ""
            if (id.contains("reel") || id.contains("shorts") ||
                text == "reels" || text == "shorts" ||
                desc.contains("reel") && n.isSelected ||
                desc.contains("shorts") && n.isSelected
            ) return true
            for (i in 0 until n.childCount) n.getChild(i)?.let { stack.add(it) }
        }
        return false
    }

    private fun nudge() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val mood = prefs.getString("mood", "Happy") ?: "Happy"
        val weather = prefs.getString("weather", "") ?: ""
        val task = Suggestions.task()
        val temp = prefs.getInt("temp", -99)
        val weatherLine = if (weather.isNotEmpty() && temp != -99)
            "${Weather.pretty(weather)}, $temp°C. ${Weather.tip(weather)}" else ""

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val songUri = Uri.parse(
            "https://www.youtube.com/results?search_query=" +
                URLEncoder.encode(Suggestions.songQuery(mood, weather), "UTF-8")
        )
        val song = PendingIntent.getActivity(
            this, 1, Intent(Intent.ACTION_VIEW, songUri),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Time check - your exam is coming")
            .setContentText(task)
            .setStyle(Notification.BigTextStyle().bigText(task))
            .setSubText(weatherLine)
            .setContentIntent(open)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_play),
                    "Kannada melody",
                    song
                ).build()
            )
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(1, n)
        Toast.makeText(this, task, Toast.LENGTH_LONG).show()
    }
}
