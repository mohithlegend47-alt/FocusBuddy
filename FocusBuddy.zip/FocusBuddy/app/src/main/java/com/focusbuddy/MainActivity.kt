package com.focusbuddy

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import java.net.URLEncoder

class MainActivity : Activity() {

    private val moods = arrayOf("Happy", "Sad", "Stressed", "Sleepy", "Focused")
    private val cities = Cities.list.keys.toTypedArray()

    private lateinit var statusTv: TextView
    private lateinit var watchingTv: TextView
    private lateinit var todayTv: TextView
    private lateinit var weatherTv: TextView
    private lateinit var tipTv: TextView
    private lateinit var taskTv: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            updateLive()
            handler.postDelayed(this, 3000)
        }
    }

    private fun prefs() = getSharedPreferences(WatcherService.PREFS, MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = prefs()
        val pad = (16 * resources.displayMetrics.density).toInt()

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun label(size: Float, bold: Boolean = false) = TextView(this).apply {
            textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, pad / 2, 0, pad / 2)
        }

        root.addView(label(26f, true).apply { text = "Focus Buddy" })

        // --- Screen watcher ---
        statusTv = label(16f)
        root.addView(statusTv)
        watchingTv = label(14f)
        root.addView(watchingTv)
        root.addView(Button(this).apply {
            text = "Turn on screen watcher"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        todayTv = label(16f)
        root.addView(todayTv)

        // --- Mood ---
        root.addView(label(14f).apply { text = "How is your mood?" })
        val moodSpinner = Spinner(this)
        moodSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, moods)
        moodSpinner.setSelection(moods.indexOf(prefs.getString("mood", "Happy")).coerceAtLeast(0))
        moodSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putString("mood", moods[pos]).apply()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(moodSpinner)

        // --- Weather reporter ---
        root.addView(label(14f).apply { text = "Your city" })
        val citySpinner = Spinner(this)
        citySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, cities)
        citySpinner.setSelection(cities.indexOf(prefs.getString("city", "Bengaluru")).coerceAtLeast(0))
        citySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (prefs.getString("city", "") != cities[pos]) {
                    prefs.edit().putString("city", cities[pos]).apply()
                    loadWeather()
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(citySpinner)
        weatherTv = label(18f)
        root.addView(weatherTv)
        tipTv = label(14f)
        root.addView(tipTv)

        // --- Study task and song ---
        taskTv = label(18f).apply { text = Suggestions.task() }
        root.addView(taskTv)
        root.addView(Button(this).apply {
            text = "Give me another study task"
            setOnClickListener { taskTv.text = Suggestions.task() }
        })
        root.addView(Button(this).apply {
            text = "Play Kannada melody for my mood"
            setOnClickListener {
                val mood = prefs.getString("mood", "Happy") ?: "Happy"
                val weather = prefs.getString("weather", "") ?: ""
                val q = URLEncoder.encode(Suggestions.songQuery(mood, weather), "UTF-8")
                startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$q"))
                )
            }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        loadWeather()
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }

    private fun updateLive() {
        val prefs = prefs()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true
        statusTv.text = if (enabled) "Screen watcher: ON"
        else "Screen watcher: OFF. Tap the button below and enable Focus Buddy."

        val app = prefs.getString("last_app", "") ?: ""
        val state = prefs.getString("last_state", "") ?: ""
        watchingTv.text = if (enabled && app.isNotEmpty()) "Last screen seen: $app ($state)" else ""

        val mins = prefs.getLong(WatcherService.todayKey(), 0L) / 60000
        todayTv.text = "Time wasted on reels/shorts/games today: $mins min"
    }

    private fun loadWeather() {
        val prefs = prefs()
        val city = prefs.getString("city", "Bengaluru") ?: "Bengaluru"
        val coords = Cities.list[city] ?: return
        weatherTv.text = "Weather in $city: checking..."
        tipTv.text = ""
        Thread {
            val w = Weather.fetch(coords.first, coords.second)
            runOnUiThread {
                if (w != null) {
                    prefs.edit().putString("weather", w.label).putInt("temp", w.tempC).apply()
                    weatherTv.text = "Weather in $city: ${Weather.pretty(w.label)}, ${w.tempC}°C"
                    tipTv.text = Weather.tip(w.label)
                } else {
                    weatherTv.text = "Weather in $city: offline"
                }
            }
        }.start()
    }
}
