# Focus Buddy (Android 10+)

An app that watches which screen you are on and pulls you back to studying.

- **Screen watcher:** detects YouTube Shorts, Instagram Reels, Snapchat, ShareChat, Facebook and games. The main screen shows the last screen it saw.
- **Nudge after 3 minutes:** a notification with a study task for the time of day, today's weather, and a "Kannada melody" button.
- **Home after 5 minutes:** sends you to the Home screen.
- **Weather reporter:** pick your Karnataka city and see live temperature, condition and a study tip.
- **Kannada melody:** opens a YouTube search matched to your mood and the weather.

## Get the APK with GitHub (no Android Studio needed)

1. Create a new repository on github.com (for example `FocusBuddy`).
2. Upload everything in this folder, including the hidden `.github` folder. Easiest: on the repo page choose "Add file" > "Upload files" and drag the whole folder contents in. If the website skips `.github`, create the file `.github/workflows/build-apk.yml` by hand with "Add file" > "Create new file" and paste the workflow from this project.
3. Open the repo's **Actions** tab. The "Build APK" run starts by itself (or press "Run workflow"). It takes 3 to 6 minutes.
4. Open the finished run and download **FocusBuddy-apk** from Artifacts. Unzip it to get `app-debug.apk`.
5. Send the APK to your phone, open it and allow "Install unknown apps" when asked.

## First run on the phone

1. Open Focus Buddy and tap "Turn on screen watcher".
2. Find Focus Buddy in Accessibility settings, turn it on and accept.
3. Pick your mood and city.

## Build in Android Studio instead

Open this folder, let Gradle sync, connect your phone with USB debugging and press Run.

## Tweaks

- Times: `NUDGE_AFTER_MS` and `HOME_AFTER_MS` in `WatcherService.kt`.
- Apps to catch: `alwaysDistracting` and `shortFormApps` in `WatcherService.kt`.
- Cities: `Cities` in `Helpers.kt`.
- Study tasks: lists in `Suggestions` in `Helpers.kt`.

## Limits

- Android 10 does not let an app take screenshots of other apps. The watcher reads screen text and view ids. If Instagram or YouTube change their internal ids, Reels/Shorts detection may need an update.
- Only the weather request uses the internet. Everything else stays on the phone.
- This is a debug APK, fine for your own phone. It was not compiled in the environment it was written in, so if the GitHub build fails, open the failed run, copy the red error and send it to me.
